#MathsPlus By Tom and Connor
from mathsplus import *
from mathsplus.pi import *
from mathsplus.hcf_lcm import *
from mathsplus.shapes import *
from mathsplus.graphs import *

print("Mathsplus successfully imported and loaded.")