Imports System
Public Module Module1
	Public slot As String
	Public number As Integer
	Public Sub Main()
		For i As Integer = 1 To 9
			For j As Integer = 1 To 9
				If j = 9 Then
					number = i * j
					If number.ToString.Length = 1 Then
						slot = "0" & number.ToString & " " & vbCrLf
					Else
						slot = number.ToString & " " & vbCrLf
					End If
					Console.Write(slot)
				Else
					number = i * j
					If number.ToString.Length = 1 Then
						slot = "0" & number.ToString & " "
					Else
						slot = number.ToString & " "
					End If
					Console.Write(slot)
				End If
			Next
		Next
	End Sub
End Module